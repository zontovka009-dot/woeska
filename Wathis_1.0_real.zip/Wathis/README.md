# Wathis 1.0

Telegram Mini App for synchronized watch rooms. Wathis coordinates rooms, users, chat and playback state while video bytes stay with the original provider whenever possible.

## Stack
- React + Vite + TypeScript
- FastAPI + SQLAlchemy async
- PostgreSQL + Redis
- aiogram 3
- WebSocket room state
- Provider adapters for YouTube, VK Video and Google Drive

## Run
1. Copy `.env.example` to `.env` and fill `BOT_TOKEN` and `WEBAPP_URL`.
2. `docker compose up --build`
3. Put the HTTPS Mini App URL into BotFather.

## Important
Provider playback is intentionally adapter-based. YouTube and VK expose controllable players; Google Drive preview has more limited programmatic control, so Wathis treats it conservatively rather than pretending all sources have identical APIs.
