# Architecture

```text
Telegram Bot -> Mini App -> FastAPI
                         |-> PostgreSQL
                         |-> Redis
                         |-> WebSocket rooms
                         |-> Provider adapters

YouTubeAdapter / VKAdapter / GoogleDriveAdapter
                    -> common VideoSource model
```

The backend is authoritative for room membership and the latest synchronized playback state. Clients send playback events; the room socket broadcasts a normalized state with a server timestamp. Video bytes are not proxied through Wathis.
