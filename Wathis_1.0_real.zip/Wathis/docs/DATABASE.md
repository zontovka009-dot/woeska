# Database

Core tables: users, sessions, memberships, friendships, messages, invitations.

A session stores the active provider, source URL/id, playback position, playing flag, playback version and updated timestamp. Membership stores role (`owner`, `admin`, `member`).
